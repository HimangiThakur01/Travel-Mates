const multer = require("multer");
const path = require("path");

//storage configuration
const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, path.join(__dirname, "uploads"));
    },

    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});

//file filter to accept only images
const upload = multer({
    storage,
    fileFilter: (req, file, cb) => {
    const fileTypes = /jpeg|jpg|png|gif/;

    if(file.mimetype.startsWith("image/")){
        cb(null, true);
    }else{
        cb(new Error("Only images are allowed"), false);
    }
  },
});


module.exports = upload;